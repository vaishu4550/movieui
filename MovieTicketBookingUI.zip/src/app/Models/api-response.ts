export interface ApiResponse {
    isSuccess: boolean,
    message: string
}
